package DataLayer;

public class Student {
    private final String id;
    private final String name;
    private final String major;

    public Student(String id, String name, String major) {
        this.id = id;
        this.name = name;
        this.major = major;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getMajor() {
        return major;
    }

    @Override
    public String toString() {
        return String.format("[ID: %s] Name: %s | Major: %s", id, name, major);
    }
}
