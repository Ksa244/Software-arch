package DataLayer;

import java.util.ArrayList;
import java.util.List;

public class Repository {
    private final List<Student> students = new ArrayList<>();

    // Singleton pattern for simple shared repository
    private static Repository instance = null;

    private Repository() {}

    public static Repository getInstance() {
        if (instance == null) {
            instance = new Repository();
        }
        return instance;
    }

    public synchronized void add(Student s) {
        students.add(s);
    }

    public synchronized Student getById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id)) {
                return s;
            }
        }
        return null;
    }

    public synchronized List<Student> searchByName(String query) {
        String q = query.toLowerCase();
        List<Student> results = new ArrayList<>();
        for (Student s : students) {
            if (s.getName().toLowerCase().contains(q)) {
                results.add(s);
            }
        }
        return results;
    }

    public synchronized List<Student> getAll() {
        return new ArrayList<>(students);
    }
}
