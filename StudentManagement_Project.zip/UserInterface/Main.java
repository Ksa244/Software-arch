package UserInterface;

import java.util.Scanner;
import ManagementLayer.Operations;
import DataLayer.Student;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Operations ops = new Operations();

    public static void main(String[] args) {
        System.out.println("=== Student Management System (Layered Architecture) ===");
        boolean running = true;
        while (running) {
            System.out.println();
            System.out.println("Select an option:");
            System.out.println("1. Add a student");
            System.out.println("2. View a student by ID");
            System.out.println("3. Search students by name");
            System.out.println("4. View all students");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            String choice = scanner.nextLine().trim();
            System.out.println();
            switch (choice) {
                case "1":
                    addStudentFlow();
                    break;
                case "2":
                    viewStudentFlow();
                    break;
                case "3":
                    searchStudentFlow();
                    break;
                case "4":
                    viewAllFlow();
                    break;
                case "5":
                    running = false;
                    System.out.println("Exiting. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void addStudentFlow() {
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine().trim();
        System.out.print("Enter name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter major: ");
        String major = scanner.nextLine().trim();

        Student s = new Student(id, name, major);
        boolean ok = ops.addStudent(s);
        if (ok) {
            System.out.println("Student added successfully.");
        } else {
            System.out.println("Failed to add student. A student with the same ID may already exist.");
        }
    }

    private static void viewStudentFlow() {
        System.out.print("Enter student ID to view: ");
        String id = scanner.nextLine().trim();
        Student s = ops.viewStudent(id);
        if (s == null) {
            System.out.println("Student not found with ID: " + id);
        } else {
            System.out.println("Student details:");
            System.out.println(s);
        }
    }

    private static void searchStudentFlow() {
        System.out.print("Enter name or partial name to search: ");
        String query = scanner.nextLine().trim();
        var results = ops.searchStudents(query);
        if (results.isEmpty()) {
            System.out.println("No students found matching: " + query);
        } else {
            System.out.println("Found " + results.size() + " student(s):");
            for (Student s : results) {
                System.out.println(s);
            }
        }
    }

    private static void viewAllFlow() {
        var all = ops.viewAllStudents();
        if (all.isEmpty()) {
            System.out.println("No students in repository.");
        } else {
            System.out.println("All students:");
            for (Student s : all) {
                System.out.println(s);
            }
        }
    }
}
