package ManagementLayer;

import java.util.List;
import DataLayer.Repository;
import DataLayer.Student;

public class Operations {
    private final Repository repo = Repository.getInstance();

    // Add student. returns false if student with same ID already exists.
    public boolean addStudent(Student s) {
        if (repo.getById(s.getId()) != null) {
            return false; // duplicate ID
        }
        repo.add(s);
        return true;
    }

    public Student viewStudent(String id) {
        return repo.getById(id);
    }

    public List<Student> searchStudents(String nameQuery) {
        return repo.searchByName(nameQuery);
    }

    public List<Student> viewAllStudents() {
        return repo.getAll();
    }
}
